fo type="String" isViewable="false">
			</typeInfo>
			<displayInfo displayType="String">
				<enumeratedList>
					<enumRange name="ScanPropfile" minValue="!" setValue="!" text="@propsys.dll,-41304">
						<image res="%systemroot%\system32\fdprint.dll,-9">
						</image>
					</enumRange>
				</enumeratedList>
			</displayInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Bluetooth.DeviceAddress" formatID="{2BD67D8B-8BEB-48D5-87E0-6CDA3428040A}" propID="1">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="String" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Bluetooth.Flags" formatID="{2BD67D8B-8BEB-48D5-87E0-6CDA3428040A}" propID="3">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt32" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Bluetooth.LastConnectedTime" formatID="{2BD67D8B-8BEB-48D5-87E0-6CDA3428040A}" propID="11">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="DateTime" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Bluetooth.Manufacturer" formatID="{2BD67D8B-8BEB-48D5-87E0-6CDA3428040A}" propID="4">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="String" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Bluetooth.ModelNumber" formatID="{2BD67D8B-8BEB-48D5-87E0-6CDA3428040A}" propID="5">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="String" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Bluetooth.ProductId" formatID="{2BD67D8B-8BEB-48D5-87E0-6CDA3428040A}" propID="8">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Bluetooth.ProductVersion" formatID="{2BD67D8B-8BEB-48D5-87E0-6CDA3428040A}" propID="9">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Bluetooth.ServiceGuid" formatID="{2BD67D8B-8BEB-48D5-87E0-6CDA3428040A}" propID="2">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="Guid" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Bluetooth.VendorId" formatID="{2BD67D8B-8BEB-48D5-87E0-6CDA3428040A}" propID="7">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Bluetooth.VendorIdSource" formatID="{2BD67D8B-8BEB-48D5-87E0-6CDA3428040A}" propID="6">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="Byte" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Hid.UsagePage" formatID="{CBF38310-4A17-4310-A1EB-247F0B67593B}" propID="2">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Hid.UsageId" formatID="{CBF38310-4A17-4310-A1EB-247F0B67593B}" propID="3">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Hid.IsReadOnly" formatID="{CBF38310-4A17-4310-A1EB-247F0B67593B}" propID="4">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="Boolean" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Hid.VendorId" formatID="{CBF38310-4A17-4310-A1EB-247F0B67593B}" propID="5">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Hid.ProductId" formatID="{CBF38310-4A17-4310-A1EB-247F0B67593B}" propID="6">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Hid.VersionNumber" formatID="{CBF38310-4A17-4310-A1EB-247F0B67593B}" propID="7">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Serial.UsbVendorId" formatID="{4C6BF15C-4C03-4AAC-91F5-64C0F852BCF4}" propID="2">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Serial.UsbProductId" formatID="{4C6BF15C-4C03-4AAC-91F5-64C0F852BCF4}" propID="3">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Serial.PortName" formatID="{4C6BF15C-4C03-4AAC-91F5-64C0F852BCF4}" propID="4">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="String" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Spb.ControllerFriendlyName" formatID="{37EBD11F-7E72-4EBC-9D4C-C790F8C277C2}" propID="2">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="String" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.PrinterName" formatID="{0A7B84EF-0C27-463F-84EF-06C5070001BE}" propID="10">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<labelInfo label="@propsys.dll,-41001">
			</labelInfo>
			<typeInfo type="String" isViewable="false">
			</typeInfo>
			<displayInfo displayType="String">
			</displayInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.PrinterDriverName" formatID="{AFC47170-14F5-498C-8F30-B0D19BE449C6}" propID="11">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<labelInfo label="@propsys.dll,-41002">
			</labelInfo>
			<typeInfo type="String" isViewable="false">
			</typeInfo>
			<displayInfo displayType="String">
			</displayInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.PrinterPortName" formatID="{EEC7B761-6F94-41B1-949F-C729720DD13C}" propID="12">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<labelInfo label="@propsys.dll,-41076">
			</labelInfo>
			<typeInfo type="String" isViewable="false">
			</typeInfo>
			<displayInfo displayType="String">
			</displayInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.PrinterDriverDirectory" formatID="{847C66DE-B8D6-4AF9-ABC3-6F4F926BC039}" propID="14">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<labelInfo label="@propsys.dll,-41281">
			</labelInfo>
			<typeInfo type="String" isViewable="false">
			</typeInfo>
			<displayInfo displayType="String">
			</displayInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.PrinterEnumerationFlag" formatID="{A00742A1-CD8C-4B37-95AB-70755587767A}" propID="3">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<labelInfo label="@propsys.dll,-42258">
			</labelInfo>
			<typeInfo type="UInt32" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.Proximity.SupportsNfc" formatID="{FB3842CD-9E2A-4F83-8FCC-4B0761139AE9}" propID="2">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<labelInfo label="@propsys.dll,-41803">
			</labelInfo>
			<typeInfo type="Boolean" isViewable="false">
			</typeInfo>
			<displayInfo displayType="Boolean">
			</displayInfo>
		</propertyDescription>
		<propertyDescription name="System.Device.PrinterURL" formatID="{0B48F35A-BE6E-4F17-B108-3C4073D1669A}" propID="15">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<labelInfo label="@propsys.dll,-41297">
			</labelInfo>
			<typeInfo type="String" isViewable="false">
			</typeInfo>
			<displayInfo displayType="String">
			</displayInfo>
		</propertyDescription>
		<propertyDescription name="System.Devices.WiaDeviceType" formatID="{6BDD1FC6-810F-11D0-BEC7-08002BE2092F}" propID="2">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt32" isInnate="true" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.Storage.Portable" formatID="{4D1EBEE8-0803-4774-9842-B77DB50265E9}" propID="2">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="Boolean" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.Storage.RemovableMedia" formatID="{4D1EBEE8-0803-4774-9842-B77DB50265E9}" propID="3">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="Boolean" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.Storage.SystemCritical" formatID="{4D1EBEE8-0803-4774-9842-B77DB50265E9}" propID="4">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="Boolean" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.WinUsb.UsbVendorId" formatID="{95E127B5-79CC-4E83-9C9E-8422187B3E0E}" propID="2">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name="System.DeviceInterface.WinUsb.UsbProductId" formatID="{95E127B5-79CC-4E83-9C9E-8422187B3E0E}" propID="3">
			<searchInfo inInvertedIndex="false" isColumn="false">
			</searchInfo>
			<typeInfo type="UInt16" isViewable="false">
			</typeInfo>
		</propertyDescription>
		<propertyDescription name