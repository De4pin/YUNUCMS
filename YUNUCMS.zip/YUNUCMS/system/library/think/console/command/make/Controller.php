ivatableClassId="PhotosApp.Model.Thumbnails.StreamBasedThumbnailSource" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Model.Thumbnails.WPDRequestInfo" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Model.Thumbnails.ThumbnailRequestInfo" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Tracing.AppStubTracing" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Tracing.VersionHelper" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.BackgroundTasks.UploadAlbumsProvider" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.BackgroundTasks.UpdateBackgroundTask" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.BackgroundTasks.OobeBackgroundTaskStarter" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.BackgroundTasks.BackgroundTaskStarter" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.PageBase" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Pano.PanoViewerControl" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.ToastNotificationService" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.AutoFix.NDERenderHelper" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.BadgeProperties" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Tiles.SetTile" ThreadingModel="both" />
        <ActivatableClass ActivatableClas