tivatableClassId="AppCore.Print.PrintService" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="AppCore.ModifierKeyStatesRT" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="AppCore.ThinPlayPauseButton" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="AppCore.ToastLaunchParameters" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="AppCore.NarratorDurationFormatter" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="AppCore.DelayLoadContentControl" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="AppCore.FullScreenNotification" ThreadingModel="both" />
      </InProcessServer>
    </Extension>
    <Extension Category="windows.activatableClass.inProcessServer">
      <InProcessServer>
        <Path>PhotosApp.Windows.dll</Path>
        <ActivatableClass ActivatableClassId="PhotosApp.EditPickerList" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.ViewModelBase" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.RichMediaDelegatesService" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.CacheHelper" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.AutoEnhance.Helpers.AutoEnhanceRenderHelper" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Settings.ThrottleFeedbackSetting" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Settings.FacebookSetting" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Settings.LastActiveAppSessionSetting" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Settings.AutoEnhanceSetting" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Settings.OneDriveSetting" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Settings.StartTileModeSetting" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.NativeShareHelper" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.UploadProgressService" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.DatabaseService" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.ViewerFlipView" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.VideoPreviewControl" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.FileMetadataModelStatic" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.ImagePreviewControl" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.RotationBehavior" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.RichMediaSingleItemSurfaceCache" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.ViewerFlipViewItemAutomationPeer" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.ThumbnailScaler" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.ViewerControlViewModel" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.SlideshowNavigationState" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.ViewerControl" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.RichEditResult" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.GeolocationLookup" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.BooleanToOpacityConverter" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.AutoEnhanceTelemetryInformation" ThreadingModel="both" />
        <ActivatableClass ActivatableClassId="PhotosApp.Viewer.RichMediaUtils" ThreadingModel="both" 