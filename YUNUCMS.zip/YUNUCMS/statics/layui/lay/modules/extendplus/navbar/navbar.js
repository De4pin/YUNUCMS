MathType Output Translator 1.0: "Stack Exchange: Theoretical Comp Sci", "Stack Exchange: Theoretical Comp Sci translator v1.00 by Design Science, Inc.", application

// Copyright (c) 1998-2012 by Design Science, Inc.
// License: You are allowed to create your own translators based on the contents of this file
// solely for use with MathType. It is recommended that you change the filename, title, and description
// in the first line of this file so as to reflect your modifications and the change of author and purpose.
// Design Science, Inc. is not responsible for any damages caused by the use of this file or derived works.

// $Header: /MathType/Translators/StackExchange-TCS.tdl 1     10/11/12 2:10p Eduardot $

include "MathJax-LaTeX (base vars).tdl";
// redefinitions of base variables
var/"TranslatorName" = "Stack Exchange: Theoretical Comp Sci";
var/"TranslatorFileName" = "StackExchange-TCS.tdl";

var/"BeginMathDisplay" = "$$";
var/"BeginMathInline" = "$";
var/"EndMathDisplay" = "$$";
var/"EndMathInline" = "$";

include "MathJax-LaTeX (base rules).tdl";
// redefinition of base rules
eqn         = "<BeginMathDisplay>#@n<EqnDataCmt><EndMathDisplay>";     //  $$ <eqn> MTEF $$  -- display equation translation
eqn/inline  = "<BeginMathInline>#@n<EqnDataCmt><EndMathInline>";       //   $ <eqn> MTEF $   -- in-line equation translation
                                                                                                                                                                ��的容器，请检查.', '出错');
        }
        if (_config.data === undefined && _config.url === undefined) {
            common.layerAlertE('Navbar error:请为Navbar配置数据源.', '出错')
        }
        if (_config.data !== undefined && typeof (_config.data) === 'object') {
            var html = getHtml(_config.data);
            $container.html(html);
            element.init();
            _that.config.elem = $container;
        } else {
            if (_config.cached) {
                var cacheNavbar = layui.data(cacheName);
                if (cacheNavbar.navbar === undefined) {
                    $.ajax({
                        type: _config.type,
                        url: _config.url,
                        async: false, //_config.async,

                        dataType: 'json',
                        success: function (result, status, xhr) {
                            //添加缓存
                            layui.data(cacheName, {
                                key: 'navbar',
                                value: result
                            });
                            var html = getHtml(result);
                            $container.html(html);
                            element.init();
                        },
                        error: function (xhr, status, error) {
                            common.msgError('Navbar error:' + error);
                        },
                        complete: function (xhr, status) {
                            _that.config.elem = $container;
                        }
                    });
                } else {
                    var html = getHtml(cacheNavbar.navbar);
                    $container.html(html);
                    element.init();
                    _that.config.elem = $container;
                }
            } else {
                //清空缓存
                layui.data(cacheName, null);
                $.ajax({
                    type: _config.type,
                    url: _config.url,
                    async: false, //_config.async,

                    dataType: 'json',
                    success: function (result, status, xhr) {
                        var html = getHtml(result);
                        $container.html(html);
                        element.init();
                    },
                    error: function (xhr, status, error) {
                        common.msgError('Navbar error:' + error);
          MathType Output Translator 1.0: "StudySync", "StudySync translator v1.00 by Design Science, Inc.", website, html, public

// Copyright (c) 1998-2010 by Design Science, Inc.
// License: You are allowed to create your own translators based on the contents of this file
// solely for use with MathType. It is recommended that you change the filename, title, and description
// in the first line of this file so as to reflect your modifications and the change of author and purpose.
// Design Science, Inc. is not responsible for any damages caused by the use of this file or derived works.

// $Header: /MathType/Translators/StudySync.tdl 1     11/03/11 10:55a Eduardot $

include "Google (chart api vars).tdl";
// redefinitions of base variables

var/"TranslatorName" = "StudySync";
var/"TranslatorFileName" = "StudySync.tdl";

include "Google (chart api rules).tdl";

                                                                                                                                           == undefined) {
                _con.children('ul').find('li').each(function () {
                    var $this = $(this);
                    if ($this.find('dl').length > 0) {
                        var $dd = $this.find('dd').each(function () {
                            $(this).on('click', function () {
                                var $a = $(this).children('a');
                                var href = $a.data('url');
                                var icon = $a.children('i').attr('class');
                                var title = $a.children('cite').text();
                                var data = {
                                    elem: $a,
                                    field: {
                                        href: href,
                                        icon: icon,
                                        title: title
                                    }
                                }
                                callback(data);
                                //$(this).parent('dl').parent('li').addClass('layui-this').siblings().removeClass('layui-this');
                            });
                        });
                    } else {
                        $this.on('click', function () {
                            var $a = $this.children('a');
                            var href = $a.data('url');
                            var icon = $a.children('i').attr('class');
                            var title = $a.children('cite').text();
                            var data = {
                                elem: $a,
                                field: {
                                    href: href,
                                    icon: icon,
                                    title: title
                                }
                            }
                            callback(data);
                            //$this.addClass('layui-this').siblings().removeClass('layui-this');
                        });
                    }
                });
            }
        }
    };
    /**
	 * 获取html字符串
	 * @param {Object} data
	 */
    function getHtml(data) {
        var ulHtml = '<div id="sidebar" class="sidebar-fold"><i class="fa fa-bars"></i></div><ul class="layui-nav layui-nav-tree admin-nav-tree">';
        for (var i = 0; i < data.length; i++) {
            if (data[i].spread) {
                ulHtml += '<li class="layui-nav-item layui-nav-itemed">';
            } else {
                ulHtml += '<li class="layui-nav-item">';
            }
            if (data[i].children !== undefined && data[i].children.length > 0) {
                ulHtml += '<a href="javascript:;">';
                if (data[i].icon !== undefined && data[i].icon !== '') {
                    if (data[i].icon.indexOf('fa-') !== -1) {
                        ulHtml += '<i class="' + data[i].icon + '" aria-hidden="true"></i>';
                    } else {
                        ulHtml += '<i INDX( 	 /`B           (   �  �        ��    d          Q|    p \     �{    h'��|�V����h'��|�h'��|�       q              S p r i n g p a d . t d l     Q|    p Z     �{    h'��|�V����h'��|�h'��|�       q              S P R I N G ~ 1 . T D L       R|    h T     �{    h'��|�������h'��|�h'��|�       `              	S p r u z . t d l     X|    p Z     �{    h'��|�������h'��|�h'��|�       `              S T 7 7 7 2 ~ 1 . T D L e - E W|    p Z     �{    h'��|�������h'��|�h'��|�       ^              S T 8 8 A 5 ~ 1 . T D L e - E S|    � j     �{    h'��|�������h'��|�h'��|�       e              S t a c k E x c h a n g e - E E . t d l       T|    x h     �{    h'��|�������h'��|�h'��|�       A              S t a c k E x c h a n g e - M . t d l U|    x h     �{    h'��|�������h'��|�h'��|�       5              S t a c k E x c h a n g e - P . t d l V|    � j     �{    h'��|������ h'��|�h'��|�       ^              S t a c k E x c h a n g e - Q F . t d l Z     W|    � j     �{    h'��|�������h'��|�h'��|�       ^              S t a c k E x c h a n g e - S A . t d l Z     X|    � l     �{    h'��|�������h'��|�h'��|�       `              S t a c k E x c h a n g e - T C S . t d l     S|    p Z     �{    h'��|�������h'��|�h'��|�       e              S T A C K E ~ 1 . T D L       T|    p Z     �{    h'��|�������h'��|�h'��|        A              S T A C K E ~ 2 . T D L       U|    p Z     �{    h'��|�������h'��|�h'��|�       5              S T A C K E ~ 3 . T D L       V|    p Z     �{    h'��|�������h'��|�h'��|�       ^              S T A C K E ~ 4 . T D L       Y|    p \     �{    h'��|�������h'��|�h'��|�       u              S t u d y S y n c . t d l     Y|    p Z     �{    h'��|�������h'��|�h'��|�       u              S T U D Y S ~ 1 . T D L                    �{    ى��|�������ى��|�ى��|�       }              S u r v e y